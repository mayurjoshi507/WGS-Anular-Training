import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MovieResponse } from '../models/authentication/movie-response';

@Injectable({
  providedIn: 'root'
})
export class FilmServiceService {

  public films: MovieResponse[] | undefined;
  constructor(private router: Router,private httpClient: HttpClient,private route: ActivatedRoute) {
    
   }
   url = 'https://vue-js-backend.herokuapp.com/movies/search?';
   


   search(title: string): Observable<MovieResponse>{
    const options = {
      params: new HttpParams().set('title', title)
    }
    
    return this.httpClient.get<MovieResponse>(this.url,{params:options.params});
  }
  
}
