import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'startRating'
})
export class StartRatingPipe implements PipeTransform {

  transform(value: String) : String{
        if(value >= '85')

    value = '★★★★';

 else if(value< '85' && value >= '75')

   value = '★★★';

 else if(value < '75')

   value = '★★'

 return value;
  }

}
